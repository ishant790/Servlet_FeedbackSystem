package com.example.feedback;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "FeedbackServlet", value = "/FeedbackServlet")
public class FeedbackServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check for existing submission using session
        HttpSession session = request.getSession();
        if (session.getAttribute("hasSubmitted") != null) {
            response.sendRedirect("alreadySubmitted.jsp");
            return;
        }

        // Get form parameters
        String studentName = request.getParameter("studentName");
        String email = request.getParameter("email");
        String course = request.getParameter("course");
        String feedbackText = request.getParameter("feedback");

        // Validate input
        if (studentName == null || studentName.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            course == null || course.trim().isEmpty() ||
            feedbackText == null || feedbackText.trim().isEmpty()) {
            
            response.sendRedirect("index.jsp?error=1");
            return;
        }

        // Mark submission in session
        session.setAttribute("hasSubmitted", true);
        
        // Set cookie to track submission
        Cookie feedbackCookie = new Cookie("feedbackSubmitted", "true");
        feedbackCookie.setMaxAge(30 * 24 * 60 * 60); // 30 days
        response.addCookie(feedbackCookie);

        // Generate confirmation response
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Feedback Confirmation</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; margin: 40px; }");
            out.println(".confirmation { background: #f5f5f5; padding: 20px; border-radius: 5px; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Thank You for Your Feedback!</h1>");
            out.println("<div class='confirmation'>");
            out.println("<h2>Submission Details</h2>");
            out.println("<p><strong>Name:</strong> " + studentName + "</p>");
            out.println("<p><strong>Email:</strong> " + email + "</p>");
            out.println("<p><strong>Course:</strong> " + course + "</p>");
            out.println("<p><strong>Feedback:</strong> " + feedbackText + "</p>");
            out.println("</div>");
            out.println("<p><a href='index.jsp'>Return to Feedback Form</a></p>");
            out.println("</body>");
            out.println("</html>");
        }
        
       
    }
}